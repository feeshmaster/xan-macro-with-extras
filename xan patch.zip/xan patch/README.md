this isn't an actual release of xan so check out the real thing from their discord here: https://discord.gg/yGjcaVdhQA

# what it adds
- config switcher
- auto load for config(idk why it doesn't already do that)